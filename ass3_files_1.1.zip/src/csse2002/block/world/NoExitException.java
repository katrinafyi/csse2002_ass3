package csse2002.block.world;

/**
 * Exit does not exist.
 * @serial exclude
 */
public class NoExitException extends BlockWorldException {

}
