package csse2002.block.world;

/**
 * The block is invalid for a particular operation.
* @serial exclude
*/
public class InvalidBlockException extends BlockWorldException {

}
